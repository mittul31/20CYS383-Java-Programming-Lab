package com.amrita.jpl.cys21042.practice.assignments;
import java.util.*;
/**
 * @Author Mittul R CB.EN.U4CYS21042
 */
public class addition {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Value of First Number : ");
        int a=sc.nextInt();
        System.out.println("Enter the Value of Second Number : ");
        int b=sc.nextInt();
        int sum=a+b;
        System.out.println("Addition of Given Two Numbers is "+sum);
    }
}
